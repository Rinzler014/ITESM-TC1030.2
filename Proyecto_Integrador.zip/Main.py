#Instituto Tecnologico de Estudios Superiores de Monterrey
#Ricardo Adolfo González Terán
#A01769410
#Anatanael Jesús Miranda Faustino
#A01769232
#Actvidad en este programa: Main del Proyecto integrador

#----IMPORTS---

from Proyecto_Integrador import Eleccion, Menu

#----MAIN----

menu=Eleccion()
menu.inicio_de_menu()

